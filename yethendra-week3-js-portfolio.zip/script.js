/* =========================================================
   Week 3: JavaScript - Making Websites Interactive
   Author: Yethendra Sai Gantala
   ========================================================= */

// 1. Dark / Light Mode Toggle with localStorage
const themeToggleBtn = document.getElementById('theme-toggle');

function applySavedTheme() {
  const isDark = localStorage.getItem('darkMode') === 'true';
  document.body.classList.toggle('dark-mode', isDark);
  themeToggleBtn.innerHTML = isDark ? '&#9728; Light Mode' : '&#9790; Dark Mode';
}

function toggleDarkMode() {
  const isDark = document.body.classList.toggle('dark-mode');
  localStorage.setItem('darkMode', isDark);
  themeToggleBtn.innerHTML = isDark ? '&#9728; Light Mode' : '&#9790; Dark Mode';
}

themeToggleBtn.addEventListener('click', toggleDarkMode);
applySavedTheme();

// 2. Show / Hide Extra Bio Details
const toggleBioBtn = document.getElementById('toggle-bio-btn');
const extraBio = document.getElementById('extra-bio');

toggleBioBtn.addEventListener('click', function () {
  const isHidden = extraBio.hasAttribute('hidden');
  if (isHidden) {
    extraBio.removeAttribute('hidden');
    toggleBioBtn.textContent = 'Hide Extra Details';
    toggleBioBtn.setAttribute('aria-expanded', 'true');
  } else {
    extraBio.setAttribute('hidden', '');
    toggleBioBtn.textContent = 'Show More Details';
    toggleBioBtn.setAttribute('aria-expanded', 'false');
  }
});

// 3. Skill Category Filter
const filterButtons = document.querySelectorAll('.filter-btn');
const skillCards = document.querySelectorAll('.skill-card');

filterButtons.forEach((btn) => {
  btn.addEventListener('click', function () {
    filterButtons.forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');

    const selected = btn.dataset.filter;
    skillCards.forEach((card) => {
      const matches = selected === 'all' || card.dataset.category === selected;
      card.classList.toggle('hidden-card', !matches);
    });
  });
});

// 4. Interactive Milestone Slider
const sliderTrack = document.getElementById('slider-track');
const slides = document.querySelectorAll('.slide-card');
const prevSlideBtn = document.getElementById('prev-slide');
const nextSlideBtn = document.getElementById('next-slide');
const sliderDotsContainer = document.getElementById('slider-dots');
let currentSlide = 0;

function renderSliderDots() {
  sliderDotsContainer.innerHTML = '';
  slides.forEach((_, index) => {
    const dot = document.createElement('button');
    dot.type = 'button';
    dot.className = 'slider-dot' + (index === currentSlide ? ' active' : '');
    dot.setAttribute('aria-label', `Go to slide ${index + 1}`);
    dot.addEventListener('click', () => goToSlide(index));
    sliderDotsContainer.appendChild(dot);
  });
}

function goToSlide(index) {
  currentSlide = (index + slides.length) % slides.length;
  sliderTrack.style.transform = `translateX(-${currentSlide * 100}%)`;
  renderSliderDots();
}

prevSlideBtn.addEventListener('click', () => goToSlide(currentSlide - 1));
nextSlideBtn.addEventListener('click', () => goToSlide(currentSlide + 1));
renderSliderDots();

// 5. Interactive Learning Goals List (Add / Complete / Remove + localStorage)
const goalForm = document.getElementById('goal-form');
const goalInput = document.getElementById('goal-input');
const goalList = document.getElementById('goal-list');

const defaultGoals = [
  { text: 'Build semantic HTML5 portfolio structure', completed: true },
  { text: 'Style portfolio with CSS Grid, Flexbox & gradients', completed: true },
  { text: 'Add JavaScript interactivity & localStorage persistence', completed: false }
];

let goals = JSON.parse(localStorage.getItem('portfolioGoals')) || defaultGoals;

function saveGoals() {
  localStorage.setItem('portfolioGoals', JSON.stringify(goals));
}

function renderGoals() {
  goalList.innerHTML = '';
  goals.forEach((goal, index) => {
    const li = document.createElement('li');
    li.className = 'goal-item' + (goal.completed ? ' completed' : '');

    const span = document.createElement('span');
    span.className = 'goal-text';
    span.textContent = goal.text;
    span.title = 'Click to toggle completed';
    span.addEventListener('click', () => {
      goals[index].completed = !goals[index].completed;
      saveGoals();
      renderGoals();
    });

    const delBtn = document.createElement('button');
    delBtn.type = 'button';
    delBtn.className = 'goal-delete';
    delBtn.textContent = 'Remove';
    delBtn.addEventListener('click', () => {
      goals.splice(index, 1);
      saveGoals();
      renderGoals();
    });

    li.appendChild(span);
    li.appendChild(delBtn);
    goalList.appendChild(li);
  });
}

goalForm.addEventListener('submit', function (event) {
  event.preventDefault();
  const text = goalInput.value.trim();
  if (!text) return;
  goals.push({ text, completed: false });
  goalInput.value = '';
  saveGoals();
  renderGoals();
});

renderGoals();

// 6. Real-Time JavaScript Form Validation
const contactForm = document.getElementById('contact-form');
const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');
const messageInput = document.getElementById('message');
const nameError = document.getElementById('name-error');
const emailError = document.getElementById('email-error');
const messageError = document.getElementById('message-error');
const charCount = document.getElementById('char-count');
const formStatus = document.getElementById('form-status');

function setFieldError(inputEl, errorEl, message) {
  errorEl.textContent = message;
  inputEl.classList.toggle('input-error', Boolean(message));
}

function showStatus(message, type) {
  formStatus.textContent = message;
  formStatus.className = `form-status ${type}`;
}

function validateName() {
  const val = nameInput.value.trim();
  if (val.length < 2) {
    setFieldError(nameInput, nameError, 'Please enter at least 2 characters for your name.');
    return false;
  }
  setFieldError(nameInput, nameError, '');
  return true;
}

function validateEmail() {
  const val = emailInput.value.trim();
  if (!val.includes('@') || !val.includes('.')) {
    setFieldError(emailInput, emailError, 'Please enter a valid email address.');
    return false;
  }
  setFieldError(emailInput, emailError, '');
  return true;
}

function validateMessage() {
  const val = messageInput.value.trim();
  charCount.textContent = `${val.length} / 10+ chars`;
  if (val.length < 10) {
    setFieldError(messageInput, messageError, 'Message must be at least 10 characters.');
    return false;
  }
  setFieldError(messageInput, messageError, '');
  return true;
}

nameInput.addEventListener('input', validateName);
emailInput.addEventListener('input', validateEmail);
messageInput.addEventListener('input', validateMessage);

function validateForm(event) {
  event.preventDefault();
  const isNameOk = validateName();
  const isEmailOk = validateEmail();
  const isMessageOk = validateMessage();

  if (!isNameOk || !isEmailOk || !isMessageOk) {
    showStatus('Please fix the highlighted errors before submitting.', 'error');
    return false;
  }

  const senderName = nameInput.value.trim();
  showStatus(`Message sent successfully! Thank you, ${senderName}.`, 'success');
  contactForm.reset();
  charCount.textContent = '0 / 10+ chars';
  return true;
}

contactForm.addEventListener('submit', validateForm);
