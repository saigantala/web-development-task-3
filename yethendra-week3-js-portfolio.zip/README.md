# Week 3: Interactive Personal Portfolio — Yethendra Sai Gantala

An interactive personal portfolio website built for **Week 3: JavaScript - Making Websites Interactive**, adding client-side scripting, DOM manipulation, event handling, real-time form validation, and `localStorage` persistence.

- **Author:** Yethendra Sai Gantala
- **GitHub:** [github.com/saigantala](https://github.com/saigantala)
- **LinkedIn:** [Yethendra Sai Gantala](https://www.linkedin.com/in/gantala-yethendra-sai-40953b312?utm_source=share_via&utm_content=profile&utm_medium=member_android)

## Project Structure

```text
.
├── index.html          # Semantic HTML5 structure linked to style.css & script.js
├── style.css           # External stylesheet with dark-mode variables & responsive rules
├── script.js           # External JavaScript for interactivity, DOM updates & validation
├── README.md           # Project documentation and feature guide
└── images/
    └── profile.jpg     # Portrait photo of Yethendra Sai Gantala
```

## Interactive JavaScript Features Implemented

1. **Dark / Light Mode Toggle (`localStorage`):** Persists theme preference across page reloads.
2. **Show / Hide Extra Bio Details:** Dynamically toggles hidden content with ARIA updates.
3. **Skill Category Filter:** Filters skill cards (`All`, `Frontend`, `Workflow`) using `data-category` attributes.
4. **Interactive Milestone Slider:** Previous/Next arrows and clickable dot indicators.
5. **Interactive Learning Goals Tracker:** Add, toggle complete, and remove goals dynamically with `localStorage` persistence.
6. **Real-Time Form Validation:** Live `input` and `submit` validation for Name, Email, and Message with inline error messages and a live character counter.
